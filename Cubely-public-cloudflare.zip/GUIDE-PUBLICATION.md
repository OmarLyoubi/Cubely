# Publier Cubely sur Cloudflare Workers

Ce dossier contient la version complète de Cubely avec son interface, son API et sa base de données D1. Le déploiement Cloudflare Workers fournit une URL publique en `workers.dev`.

## 1. Préparer les comptes et les outils

1. Créez un compte sur https://dash.cloudflare.com/ si nécessaire.
2. Installez Node.js 22 ou une version plus récente depuis https://nodejs.org/.
3. Ouvrez PowerShell dans ce dossier.
4. Activez pnpm :

   ```powershell
   corepack enable
   corepack prepare pnpm@latest --activate
   ```

## 2. Installer et vérifier le site

Exécutez successivement :

```powershell
pnpm install
pnpm lint
pnpm build
```

Le build doit se terminer par `Build complete`.

## 3. Se connecter à Cloudflare

```powershell
pnpm exec wrangler login
```

Une page Cloudflare s'ouvre. Autorisez Wrangler à utiliser votre compte.

## 4. Publier

```powershell
pnpm deploy
```

Lors du premier déploiement, Wrangler crée automatiquement la base D1 déclarée dans `wrangler.jsonc`. À la fin, copiez l'adresse publique affichée, normalement sous la forme :

```text
https://cubely-speedcubing.<votre-sous-domaine>.workers.dev
```

Ouvrez cette adresse et créez le premier compte. Les tables sont initialisées automatiquement et les données restent persistantes après actualisation et reconnexion.

## 5. Publier une mise à jour

Après une modification :

```powershell
pnpm lint
pnpm deploy
```

L'adresse publique reste la même.

## 6. Connecter un domaine personnel (facultatif)

Dans Cloudflare, ouvrez `Workers & Pages`, sélectionnez `cubely-speedcubing`, puis `Settings` et `Domains & Routes`. Ajoutez votre domaine ou sous-domaine et suivez les instructions affichées.

## Vérifications après publication

- La page d'accueil doit afficher `Aucune compétition disponible` tant qu'aucune compétition réelle n'a été créée.
- Créez un compte, déconnectez-vous, puis reconnectez-vous.
- Créez une compétition et vérifiez qu'elle reste visible après actualisation.
- Ajoutez des compétiteurs, créez l'ordre 1 contre 1 et publiez-le.
- Ouvrez le site sur mobile et sur ordinateur.

Ne publiez jamais le dossier `node_modules`, les fichiers `.env` ou des jetons d'accès. Ils ne sont pas inclus dans l'archive fournie.
