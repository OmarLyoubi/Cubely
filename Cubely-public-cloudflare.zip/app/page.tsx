import CubelyApp from './CubelyApp';
export default function Home(){return <CubelyApp/>}
