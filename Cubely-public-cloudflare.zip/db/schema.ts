import { integer, sqliteTable, text, uniqueIndex } from 'drizzle-orm/sqlite-core';

export const users = sqliteTable('users', {
  id: text('id').primaryKey(), name: text('name').notNull(), email: text('email').notNull(),
  passwordHash: text('password_hash').notNull(), createdAt: text('created_at').notNull(),
}, (table) => [uniqueIndex('idx_users_email').on(table.email)]);
export const sessions = sqliteTable('sessions', {
  id: text('id').primaryKey(), userId: text('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  tokenHash: text('token_hash').notNull(), expiresAt: text('expires_at').notNull(), createdAt: text('created_at').notNull(),
}, (table) => [uniqueIndex('idx_sessions_token_hash').on(table.tokenHash)]);
export const competitions = sqliteTable('competitions', {
  id: text('id').primaryKey(), title: text('title').notNull(), event: text('event').notNull(), scheduledAt: text('scheduled_at'),
  ownerId: text('owner_id').notNull().references(() => users.id), orderPublished: integer('order_published', { mode: 'boolean' }).notNull().default(false), createdAt: text('created_at').notNull(),
});
export const participants = sqliteTable('participants', {
  id: text('id').primaryKey(), competitionId: text('competition_id').notNull().references(() => competitions.id, { onDelete: 'cascade' }),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }), createdAt: text('created_at').notNull(),
}, (table) => [uniqueIndex('idx_participants_competition_user').on(table.competitionId, table.userId)]);
export const matches = sqliteTable('matches', {
  id: text('id').primaryKey(), competitionId: text('competition_id').notNull().references(() => competitions.id, { onDelete: 'cascade' }),
  position: integer('position').notNull(), playerAId: text('player_a_id').notNull().references(() => participants.id), playerBId: text('player_b_id').notNull().references(() => participants.id),
  status: text('status', { enum: ['upcoming', 'live', 'completed'] }).notNull().default('upcoming'), createdAt: text('created_at').notNull(),
}, (table) => [uniqueIndex('idx_matches_competition_position').on(table.competitionId, table.position)]);
