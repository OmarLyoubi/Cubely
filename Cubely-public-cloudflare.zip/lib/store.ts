import { env } from 'cloudflare:workers';

let schemaReady: Promise<void> | undefined;
export function getStore() { if (!env.DB) throw new Error('Base de données indisponible.'); schemaReady ??= initialize(env.DB); return { db: env.DB, ready: schemaReady }; }
async function initialize(db: D1Database) {
  await db.batch([
    db.prepare('CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, created_at TEXT NOT NULL)'),
    db.prepare('CREATE TABLE IF NOT EXISTS sessions (id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, token_hash TEXT NOT NULL UNIQUE, expires_at TEXT NOT NULL, created_at TEXT NOT NULL)'),
    db.prepare('CREATE TABLE IF NOT EXISTS competitions (id TEXT PRIMARY KEY, title TEXT NOT NULL, event TEXT NOT NULL, scheduled_at TEXT, owner_id TEXT NOT NULL REFERENCES users(id), order_published INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL)'),
    db.prepare('CREATE TABLE IF NOT EXISTS participants (id TEXT PRIMARY KEY, competition_id TEXT NOT NULL REFERENCES competitions(id) ON DELETE CASCADE, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, created_at TEXT NOT NULL, UNIQUE(competition_id,user_id))'),
    db.prepare("CREATE TABLE IF NOT EXISTS matches (id TEXT PRIMARY KEY, competition_id TEXT NOT NULL REFERENCES competitions(id) ON DELETE CASCADE, position INTEGER NOT NULL, player_a_id TEXT NOT NULL REFERENCES participants(id), player_b_id TEXT NOT NULL REFERENCES participants(id), status TEXT NOT NULL DEFAULT 'upcoming' CHECK(status IN ('upcoming','live','completed')), created_at TEXT NOT NULL, UNIQUE(competition_id,position))"),
    db.prepare('CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON sessions(user_id)'), db.prepare('CREATE INDEX IF NOT EXISTS idx_participants_competition_id ON participants(competition_id)'), db.prepare('CREATE INDEX IF NOT EXISTS idx_matches_competition_id ON matches(competition_id)'),
  ]);
}
const encoder = new TextEncoder(); const toHex=(bytes:ArrayBuffer)=>[...new Uint8Array(bytes)].map(v=>v.toString(16).padStart(2,'0')).join('');
export async function sha256(value:string){return toHex(await crypto.subtle.digest('SHA-256',encoder.encode(value)))}
export async function hashPassword(password:string){const salt=crypto.getRandomValues(new Uint8Array(16));const key=await crypto.subtle.importKey('raw',encoder.encode(password),'PBKDF2',false,['deriveBits']);const hash=await crypto.subtle.deriveBits({name:'PBKDF2',salt,iterations:310000,hash:'SHA-256'},key,256);return `pbkdf2:310000:${toHex(salt.buffer)}:${toHex(hash)}`}
export async function verifyPassword(password:string,stored:string){const [,iterations,saltHex,expected]=stored.split(':');if(!iterations||!saltHex||!expected)return false;const salt=new Uint8Array(saltHex.match(/.{2}/g)!.map(v=>parseInt(v,16)));const key=await crypto.subtle.importKey('raw',encoder.encode(password),'PBKDF2',false,['deriveBits']);const actual=toHex(await crypto.subtle.deriveBits({name:'PBKDF2',salt,iterations:Number(iterations),hash:'SHA-256'},key,256));if(actual.length!==expected.length)return false;let diff=0;for(let i=0;i<actual.length;i++)diff|=actual.charCodeAt(i)^expected.charCodeAt(i);return diff===0}
